- Diminuir Pixels do painel.png
- Terminar de retirar todos os Alpha/Painel

TERMINAR SITE
