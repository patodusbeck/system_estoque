Seguindo o roadmap, vamos adicionar funcionalidades avançadas?

1. No @produtos.html adicione um sistema de carrinho.

2. Faça com que ao cliente clicar no produto, ele expanda uma tela com mais informações do produto:
   o carrossel de fotos do produtos (de 1 a 3 fotos)
   descrição do produto
   peso do produto
   valor
   um botão com 3 opções de pagamento: Pix, cartão, dinheiro vivo (em espécie)

3. Conforme a escolha da forma de pagamento, abrirá um modal pedindo o nome do cliente e endereço, conforme os dados forem repassados, o cliente será redirecionado ao contato do whatsapp especificado (5599984065730) com a mensagem:

"GAAK SUPLEMENTOS
Cliente: XXXX
Produto: XXXX
Valor e forma de pagamento: R$00,00
Endereço: Rua XXXX, Centro, n° XXXX
"

4. O restante do atendimento será humanizado e manual. Não necessita de mais nada.

O sistema registrará tudo em um banco de dados para que possamos ter um histórico de vendas e clientes.

a database será criada no MongoDB.

link de conexao
mongodb+srv://gaak_suplements:gaakpass@gaak.igh80e9.mongodb.net/?appName=gaak
